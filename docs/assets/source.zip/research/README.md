# Reproduce the release benchmark

The shipped detector is a public India-trained YOLO11n. The original student's weights and training logs were unavailable. Her five runs are reported separately in the paper and Model study.

## Re-score the distributed evidence

From the repository root, create a Python 3.11 or 3.12 environment and install the packages listed in this folder. The two compressed files contain the 775 reference entries with image hashes and per-image decoded predictions. Re-scoring requires no photograph download.

```sh
python -m pip install -r research/requirements-evaluation.txt
python scripts/score_release.py
python scripts/verify_release.py
```

## Repeat inference

```sh
python scripts/download_india.py India.zip
python scripts/prepare_rdd2022_india.py India.zip --evaluation evaluation/india-block-test
python scripts/evaluate.py evaluation/india-block-test/manifest.json --output evaluation/measured.json --predictions evaluation/predictions.jsonl.gz --block-size 25
```

Alternatively, extract the original India.zip member from the official Figshare archive. The prep step verifies the archive members as they are read and creates the labelled gallery and complete local test corpus. Run the commands from the repository root. All four classes are evaluated using the checkpoint's ordered configuration. The frozen manifest SHA-256 in the release results identifies the exact reference file. When dependencies or model settings change, keep the new measurements separate.

For each image we decode its JPEG, resize using Pillow bilinear interpolation, centre-pad to 640 × 640 with RGB 114, scale channels to [0,1], run the ONNX graph on CPU and select the maximum class score for each anchor. After clipping to the image, greedy class-wise suppression uses IoU 0.45 and the top 300 candidates. AP integration considers scores down to 0.001. Within each class, predictions are ordered by decreasing confidence. Each is matched to the best unmatched reference on the same image at IoU ≥ 0.50. Precision is interpolated at 101 recall levels and then macro-averaged over the four classes. Counts at each confidence cutoff reuse the ranked, one-to-one matches. Ties preserve the frozen manifest order.

The 2,000-replicate percentile intervals use 31 test blocks of 25 frames with replacement, seed 2026. Filename blocks approximate sequences. Their intervals cannot measure transfer uncertainty for new roads. Raw predictions use normalized top-left x, y, width and height. Gallery photos are curated and unsuitable for estimating accuracy by themselves.

**Upstream training recipe.** Original MIT-licensed Python sources from Vivek Vagale are included in public-training/. They document the source model's split, training and export. Exact retraining can vary by environment. [Upstream pinned revision](https://github.com/VivekVagale/road-hazard/tree/84673b89d7def3dcb2211ef00a10e3eb0318d0dd).

**Interpretation.** The frozen result of 0.402 uses the shipped ONNX and our specified scorer. The upstream README reports 0.386 for its YOLO11n evaluation. Pipelines, preprocessing, NMS and AP implementation can produce different numbers. The difference was not isolated experimentally. The browser uses native image resampling, which can also change borderline detections. The runtime crosscheck uses identical prepared inputs to compare native ONNX and WASM outputs.
