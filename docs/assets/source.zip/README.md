# Pavement Atlas
### AI road and pavement condition survey system

Open a road photograph, run a real India-trained detector, review the proposed damage, then save a location-aware survey record. The whole application runs from static files on GitHub Pages. The first analysis loads the bundled model and its WebAssembly runtime from the same site. Survey photographs, notes and locations stay in IndexedDB on the device.

## Host it on GitHub Pages

1. Extract the project ZIP. Open the **Pavement-Atlas** folder. At its top level you should see **docs**, **scripts**, **research**, **LICENSE** and this README.
2. Sign in to GitHub and create a repository named **pavement-atlas**. A public repository works with GitHub Free. Use the branch name **main**. If you prefer the browser upload route, initialize the repository with a README.
3. Using **Add file → Upload files**, drag in the extracted project contents, preserving the folders. Commit to **main**. The correct page path in the repository is **docs/index.html**. Dragging the outer folder or the unextracted ZIP will put it in the wrong place. For a desktop workflow, use the Git commands below instead.
4. Open **Settings → Pages**. Under **Build and deployment**, set **Source** to **Deploy from a branch**. Select **main** and **/docs**, then click **Save**.
5. Once the Pages deployment succeeds, open **Visit site** in that same panel. A project site normally has the form `https://YOUR-USERNAME.github.io/pavement-atlas/`. Set up HTTPS before testing on a phone.
6. Select **India_003567**, then **Run detector**. The packaged four-class release should show damage proposals with scores. Switch to **Reference** to inspect its ten source boxes. Save a test record, reload and open **Field register** to check local persistence.

[GitHub Pages publishing-source instructions](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)

**Git alternative.** Start from an empty GitHub repository. Open a terminal in the extracted project folder and replace YOUR-USERNAME.

```sh
git init -b main
git add .
git commit -m "Release Pavement Atlas"
git remote add origin https://github.com/YOUR-USERNAME/pavement-atlas.git
git push -u origin main
```

**Local preview.** In the extracted project folder run `python -m http.server 8000 --directory docs`. On Windows, `py -m http.server 8000 --directory docs` also works. Open [http://localhost:8000](http://localhost:8000). Opening index.html as a local file prevents the normal fetch and worker workflow. No npm build, API key, paid inference service or external database is required.

## Run a survey

1. **Select a frame.** Choose one of the 16 curated Indian RDD2022 images or open your own JPEG, PNG or WebP (up to 25 MB). A sample opens with its source annotations. A field upload opens with an empty manual-review layer.
2. **Inspect at full size and in detail.** Select a point in the full-frame panel to move the 2.5× detail lens. Toggle boxes to see the underlying road surface.
3. **Run inference.** The AI layer displays predictions for D00 longitudinal crack, D10 transverse crack, D20 alligator crack and D40 pothole. Set the confidence cutoff to change the visible overlays. Review low-confidence candidates in the box list. The measured study tab shows what three cutoffs did to precision and recall on a labelled cohort.
4. **Correct the record.** Under **Box review**, edit the class, position or reviewer decision. Coordinates are normalized top-left x, y, width and height. **Draw box** adds a missed defect. Rejected boxes remain in the audit data. An original class and box are retained for comparison. A manual reviewer may also use “other corruption”, outside the default detector's four-class vocabulary.
5. **Add the field context.** Enter a road or route name, notes and optional latitude and longitude. Both coordinates are required as a pair. **Use device location** captures the device's location at review time. For photographs taken elsewhere, enter the capture location manually. RDD2022 examples have no location assigned by the app.
6. **Save.** Both layers, the active layer, date of the save, model identity, cutoff, review decisions, notes and field-upload image are retained. Reopen the same record to update it. Selecting a gallery frame anew starts a separate observation.
7. **Inspect and export.** Field register counts accepted boxes on each record's saved active layer. The route chart shows the mix of accepted classes. CSV has one row per box on the active layer and one row for empty frames. GeoJSON holds located frames as WGS84 points in longitude, latitude order. JSON includes both layers and audit metadata. All three export all applicable records, regardless of the current search. Exports omit photograph bytes. Keep original field photographs alongside exports. Clearing browser data removes locally saved records. Different devices, browser profiles and site origins have separate registers.

## Dataset, model and results

The official RDD2022 challenge evaluates four classes. The student's Kaggle-based study reported five, including “other corruption”. Her supervised runs, their evaluation domains and three available India test scores appear in **Model study** and in the paper. This release ships a public YOLO11n checkpoint by Vivek Vagale, so new photos can be analysed immediately. The student's checkpoint and training logs were unavailable.

| Release detector on its 775-frame India block test | Result |
|---|---:|
| Labelled boxes | 736 |
| mAP50, 101-point | 0.402 |
| Precision / recall at confidence 0.25 | 0.643 / 0.421 |
| Matched / false alarms / missed | 310 / 172 / 426 |
| D00 / D10 / D20 / D40 AP50 | 0.351 / 0.144 / 0.687 / 0.426 |

These results describe the public checkpoint and the reconstruction of its developer's split. The gallery is a curated set for interface review. None of these scores estimates accuracy on an Ongole road without locally reviewed ground truth. No road severity or Pavement Condition Index is inferred.

[Model card](docs/model/MODEL_CARD.md) · [Data attribution and selection](docs/data/ATTRIBUTION.md) · [Reproducibility notes](research/README.md) · [Machine-readable evaluation](research/india-public-checkpoint-evaluation.json)

## Use Sarala's model when it arrives

Obtain the **best.pt** for the specified run, the **data.yaml** with the ordered names, split identifiers, training arguments, **results.csv** and validation/test summaries. The 0.413 run is the best reported India-validation candidate. Its India test measurement is still needed.

1. In a clean Python environment install `ultralytics onnx onnxruntime numpy`. Work only with a trusted .pt supplied by the researcher.
2. Create **class-map.json** mapping each exact checkpoint class name to one supported code: D00, D10, D20, D40 or OTHER. The export script verifies the names against the model. Use the actual training labels.
3. Run the staging export from the project root:

```sh
python scripts/export_student_model.py best.pt --name "Sarala YOLOv8s - India plus 3000" --class-map class-map.json --output student-export
```

4. Keep a copy of the public checkpoint configuration. Evaluate the staged checkpoint against the correct split and label mapping. The four-class public benchmark does not evaluate an unmapped fifth class. Compare Python predictions and browser predictions on reference images, including empty images and rare classes.
5. Copy the staged ONNX and matching config.json into **docs/model** together. Refresh the app, check the displayed checkpoint name and verify the new output. Retain licensing and source materials. The historical benchmark in **Model study** describes the public release checkpoint until you explicitly add separate evidence for the replacement.

## Project layout

| Folder | Contents |
|---|---|
| docs/ | Application, survey records, review interface and model study |
| docs/data/ | Original example JPEGs, normalized boxes, attribution and release metrics |
| docs/model/ | ONNX weights, model card, decoder, worker, runtime and licences |
| scripts/ | Rebuild dataset, evaluate detections, validate release, export student weights |
| research/ | Full per-image evaluation artefacts, benchmark results and upstream training scripts |
| paper/ | Editable conference manuscript source and figures |

## Troubleshooting

| Symptom | Check |
|---|---|
| GitHub Pages returns 404 | Verify **main /docs** is selected and **docs/index.html** appears at exactly this path. Inspect the latest Pages deployment run. |
| Frame appears but inference fails | Open the HTTPS site or localhost in a recent browser with WebAssembly SIMD support. Ensure the entire **docs/model/vendor** directory, including its .wasm file, and the .onnx file were uploaded as binary files. |
| Model checksum mismatch | Restore the original model file and matching config, or re-export the replacement as a pair. A Git LFS pointer is not the ONNX binary. |
| No detections above cutoff | Lower the cutoff and inspect the frame manually. The four-class model has limited recall, particularly for transverse cracking. |
| Storage/location error | Use a regular browser profile with available storage. Enter coordinates manually when device location permission is unavailable. |

## Licences and attribution

The original application code is distributed under GNU AGPL-3.0. The checkpoint embeds an AGPL-3.0 notice. The upstream research scripts and ONNX Runtime include their own licences. The official RDD2022 imagery and reference boxes are credited to Arya et al., CC BY 4.0. Keep the included source, licences and data attribution with redistributed versions.
