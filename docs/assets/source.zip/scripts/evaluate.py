"""Evaluate one exported raw YOLO Detect head on a labelled survey manifest.

Requires Python 3.10+, numpy, Pillow, onnxruntime. The manifest schema is the
same as docs/data/manifest.json (pass --image-root docs for that gallery). Outputs are evaluated at IoU >= 0.50.
"""
import argparse
import gzip
import hashlib
import json
import os
from io import BytesIO
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from threading import local

import numpy as np
from PIL import Image
import onnxruntime as ort

ROOT = Path(__file__).resolve().parents[1]
STATE = local()


def preprocess(image, size):
    image = image.convert("RGB")
    width, height = image.size
    scale = min(size / width, size / height)
    # Match JavaScript Math.round for nonnegative values.
    sw = max(1, int(scale * width + 0.5))
    sh = max(1, int(scale * height + 0.5))
    left, top = (size - sw) // 2, (size - sh) // 2
    canvas = Image.new("RGB", (size, size), (114, 114, 114))
    canvas.paste(image.resize((sw, sh), Image.Resampling.BILINEAR), (left, top))
    tensor = np.asarray(canvas, dtype=np.float32).transpose(2, 0, 1)[None] / 255
    return tensor, (left, top, sw, sh)


def overlap(box, boxes):
    """Pair one normalized xywh rectangle with a batch of rectangles."""
    if not len(boxes):
        return np.zeros(0)
    upper = np.maximum(box[:2], boxes[:, :2])
    lower = np.minimum(box[:2] + box[2:], boxes[:, :2] + boxes[:, 2:])
    inter = np.prod(np.maximum(0, lower - upper), axis=1)
    union = np.prod(box[2:]) + np.prod(boxes[:, 2:], axis=1) - inter
    return np.divide(inter, union, out=np.zeros_like(inter), where=union > 0)


def decode(out, geometry, config, conf):
    classes = config["classes"]
    if out.ndim != 3 or out.shape[:2] != (1, 4 + len(classes)):
        raise ValueError(f"Unsupported output shape {out.shape}")
    data = out[0].T
    labels = data[:, 4:].argmax(axis=1)
    scores = data[np.arange(len(data)), labels + 4]
    ids = np.flatnonzero(np.isfinite(scores) & (scores >= conf) & (scores > 0) & (scores <= 1))
    ids = ids[np.argsort(-scores[ids], kind="stable")]
    left, top, sw, sh = geometry
    centered = data[ids, :4].astype(float)
    start = ((centered[:, :2] - centered[:, 2:] / 2 - [left, top]) / [sw, sh]).clip(0, 1)
    end = ((centered[:, :2] + centered[:, 2:] / 2 - [left, top]) / [sw, sh]).clip(0, 1)
    boxes = np.column_stack((start, end - start))
    keep = []
    active = np.flatnonzero(np.all(end > start, axis=1))
    while len(active) and len(keep) < 300:
        first = active[0]
        keep.append((classes[labels[ids[first]]], float(scores[ids[first]]), boxes[first].tolist()))
        rest = active[1:]
        duplicates = ((labels[ids[rest]] == labels[ids[first]]) &
                      (overlap(boxes[first], boxes[rest]) > config["nmsIou"]))
        active = rest[~duplicates]
    return keep


def infer(entry, manifest_dir, config, weights, conf):
    if not hasattr(STATE, "engine"):
        options = ort.SessionOptions()
        options.intra_op_num_threads = 1
        options.inter_op_num_threads = 1
        STATE.engine = ort.InferenceSession(str(weights), options, providers=["CPUExecutionProvider"])
    image_bytes = (manifest_dir / entry["src"]).read_bytes()
    if entry.get("sha256") and hashlib.sha256(image_bytes).hexdigest() != entry["sha256"]:
        raise ValueError(f"Image checksum differs from manifest for {entry['id']}")
    with Image.open(BytesIO(image_bytes)) as im:
        if im.size != (entry["width"], entry["height"]):
            raise ValueError(f"Image dimensions differ from manifest for {entry['id']}")
        data, geometry = preprocess(im, config["size"])
    engine = STATE.engine
    out = engine.run(None, {engine.get_inputs()[0].name: data})[0]
    return decode(out, geometry, config, conf)


def metrics(entries, predictions, classes, operational_cutoff):
    summary = {}
    image_counts = {e["id"]: [0, 0, 0] for e in entries}  # TP, predicted, truth
    thresholds = sorted({0.10, 0.25, 0.50, operational_cutoff})
    sweep = {cutoff: [0, 0] for cutoff in thresholds}
    for code in classes:
        truth = {}
        for e in entries:
            rows = [[b[k] for k in ["x","y","w","h"]] for b in e["boxes"] if b["label"] == code]
            truth[e["id"]] = np.array(rows, dtype=float).reshape(-1, 4)
        count = sum(map(len, truth.values()))
        for image_id, boxes in truth.items():
            image_counts[image_id][2] += len(boxes)
        matched = {key: np.zeros(len(value), dtype=bool) for key, value in truth.items()}
        ranked = [(score, e["id"], np.array(box)) for e, ds in zip(entries, predictions)
                  for label, score, box in ds if label == code]
        ranked.sort(key=lambda row: -row[0])
        tp = []
        for score, image_id, box in ranked:
            ious = overlap(box, truth[image_id])
            ious[matched[image_id]] = -1
            best = int(ious.argmax()) if len(ious) else -1
            ok = best >= 0 and ious[best] >= 0.5
            if ok:
                matched[image_id][best] = True
            tp.append(int(ok))
            if score >= operational_cutoff:
                image_counts[image_id][0] += int(ok)
                image_counts[image_id][1] += 1
            for cutoff in thresholds:
                if score >= cutoff:
                    sweep[cutoff][0] += int(ok)
                    sweep[cutoff][1] += 1
        hits = np.cumsum(tp)
        precision = hits / np.arange(1, len(tp) + 1)
        recall = hits / max(1, count)
        ap = None if count == 0 else float(np.mean([
            np.max(precision[recall >= target], initial=0) for target in np.linspace(0, 1, 101)
        ]))
        n = sum(score >= operational_cutoff for score, *_ in ranked)
        correct = sum(tp[:n])
        summary[code] = {"ground_truth": count, "ap50_101": ap, "predictions": n,
                         "tp": correct, "fp": n - correct, "fn": count - correct}
    t = sum(d["tp"] for d in summary.values())
    p = sum(d["predictions"] for d in summary.values())
    n = sum(d["ground_truth"] for d in summary.values())
    curve = [{"threshold": cutoff, "tp": hit, "fp": candidates-hit, "fn": n-hit,
              "micro_precision": hit/candidates if candidates else None, "micro_recall": hit/n if n else None}
             for cutoff, (hit, candidates) in sweep.items()]
    return {"operating_points": curve, "per_class": summary, "mAP50_101": float(np.mean([d["ap50_101"] for d in summary.values()
                                                              if d["ap50_101"] is not None])),
            "micro_precision": t / p if p else None, "micro_recall": t / n if n else None,
            "tp": t, "fp": p - t, "fn": n - t}, np.array(list(image_counts.values()))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("manifest", type=Path)
    p.add_argument("--config", type=Path, default=ROOT / "docs/model/config.json")
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--image-root", type=Path, help="Source-path base; default is manifest directory")
    p.add_argument("--block-size", type=int, help="Block bootstrap only for complete, consecutive equal-size blocks")
    p.add_argument("--predictions", type=Path, help="Optional gzipped JSONL audit trail at AP cutoff")
    p.add_argument("--workers", type=int, default=min(4, os.cpu_count() or 1))
    p.add_argument("--ap-cutoff", type=float, default=0.001)
    p.add_argument("--operating-cutoff", type=float, default=0.25)
    args = p.parse_args()
    if not 0 < args.ap_cutoff <= args.operating_cutoff <= 1:
        p.error("Require 0 < AP cutoff <= operating cutoff <= 1.")
    config = json.loads(args.config.read_text())
    weights = args.config.parent / config["weights"]
    actual = hashlib.sha256(weights.read_bytes()).hexdigest()
    if actual != config["sha256"]:
        raise ValueError("Model checksum mismatch")
    entries = json.loads(args.manifest.read_text())["images"]
    if not entries or len({e["id"] for e in entries}) != len(entries):
        raise ValueError("Empty evaluation set or repeated image IDs")
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        predictions = list(pool.map(lambda entry: infer(entry, args.image_root or args.manifest.parent, config, weights,
                                                         args.ap_cutoff), entries))
    scored, per_image = metrics(entries, predictions, config["classes"], args.operating_cutoff)
    if args.block_size:
        if args.block_size < 1 or len(entries) % args.block_size:
            p.error("The manifest must list complete, consecutive, equal-size blocks.")
        blocks = per_image.reshape(-1, args.block_size, 3).sum(axis=1)
        rng = np.random.default_rng(2026)
        draws = rng.integers(0, len(blocks), size=(2000, len(blocks)))
        totals = blocks[draws].sum(axis=1)
        hit, pred, gt = totals.T
        scored["block_bootstrap_95_percentile"] = {
            "blocks": len(blocks), "frames_per_block": args.block_size, "draws": len(draws), "seed": 2026,
            "micro_precision": np.quantile(hit[pred > 0] / pred[pred > 0], [.025, .975]).tolist(),
            "micro_recall": np.quantile(hit[gt > 0] / gt[gt > 0], [.025, .975]).tolist()}
    if args.predictions:
        with gzip.open(args.predictions, "wt", encoding="utf-8") as handle:
            for e, ds in zip(entries, predictions):
                handle.write(json.dumps({"id": e["id"], "detections": ds}, separators=(",", ":")) + "\n")
    report = {"images": len(entries), "weights_sha256": actual, "manifest_sha256":
              hashlib.sha256(args.manifest.read_bytes()).hexdigest(), "onnxruntime": ort.__version__,
              "ap_min_score": args.ap_cutoff, "operating_cutoff": args.operating_cutoff,
              "iou_match": 0.5, "nms_iou": config["nmsIou"], "max_detections_per_image": 300,
              **scored}
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
