#!/usr/bin/env python3
"""Build the public example gallery and optional model evaluation corpus from India.zip.

Input is the India.zip member of Figshare file 38030910, v1. Uses Python 3.10+.
The default evaluation split reproduces the public YOLO11n model author's
documented block assignment. Its relationship to Sarala's split is unknown.
"""
import argparse
from collections import Counter
import hashlib
import json
import random
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

CLASSES = ("D00", "D10", "D20", "D40")
SOURCE = "https://doi.org/10.6084/m9.figshare.21431547.v1"
LICENSE = "https://creativecommons.org/licenses/by/4.0/"
CREDIT = "Images and original annotations: Arya et al., RDD2022 (2022), CC BY 4.0."
SPLIT = "Public model block test"
# These feature examples are used only for inspection. Every image in the block
# test, including the examples, is counted exactly once for the full evaluation.
FEATURED_IDS = ["India_003567", "India_001687"]


def model_split(stems):
    """Match Vivek Vagale's road-hazard/src/prepare.py block_split."""
    ordered = sorted(stems)
    blocks = [ordered[start:start + 25] for start in range(0, len(ordered), 25)]
    random.Random(42).shuffle(blocks)
    result = {}
    for name, group in (
        ("train", blocks[:int(.8 * len(blocks))]),
        ("validation", blocks[int(.8 * len(blocks)):int(.9 * len(blocks))]),
        ("test", blocks[int(.9 * len(blocks)):]),
    ):
        result[name] = [stem for block in group for stem in block]
    return result


def annotations(xml):
    root = ET.fromstring(xml)
    width, height = [int(root.findtext("size/" + field)) for field in ("width", "height")]
    boxes = []
    extras = Counter()
    for obj in root.findall("object"):
        code = obj.findtext("name").strip()
        if code not in CLASSES:
            extras[code] += 1
            continue
        box = obj.find("bndbox")
        left, top, right, bottom = [float(box.findtext(key)) for key in ("xmin", "ymin", "xmax", "ymax")]
        left, right = max(0, min(left, right)), min(width, max(left, right))
        top, bottom = max(0, min(top, bottom)), min(height, max(top, bottom))
        if right - left < 2 or bottom - top < 2:
            continue
        boxes.append(dict(label=code, x=left/width, y=top/height,
                          w=(right-left)/width, h=(bottom-top)/height))
    return width, height, boxes, dict(extras)


def gallery_ids(rows):
    """Three examples per class and two negatives, favoring legible boxes."""
    chosen = list(FEATURED_IDS)
    for code in CLASSES:
        def quality(row):
            return max((min(box["w"]*box["h"], .4) for box in row["boxes"] if box["label"] == code), default=0)
        candidates = [row for row in rows if quality(row)]
        accepted = 0
        for row in sorted(candidates, key=lambda item: (-quality(item), item["id"])):
            # Avoid consecutive photos of the very same road in the gallery.
            serial = int(row["id"].split("_")[-1])
            if any(abs(serial - int(stem.split("_")[-1])) < 12 for stem in chosen):
                continue
            chosen.append(row["id"])
            accepted += 1
            if accepted == 3:
                break
    negatives = sorted((row for row in rows if not row["boxes"] and not row["otherCodes"]), key=lambda row: hashlib.sha256(row["id"].encode()).hexdigest())
    chosen.extend(row["id"] for row in negatives[:2])
    return chosen


def write_corpus(archive, members, rows, out):
    photos = out / "images"
    photos.mkdir(exist_ok=True, parents=True)
    for row in rows:
        data = archive.read(members[row["id"]])
        (photos / (row["id"] + ".jpg")).write_bytes(data)
        row["sha256"] = hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path, help="Official unmodified inner India.zip")
    parser.add_argument("--gallery", type=Path, default=Path(__file__).resolve().parents[1]/"docs/data")
    parser.add_argument("--evaluation", type=Path, help="Optionally extract all block-test images and their reference boxes")
    args = parser.parse_args()
    with zipfile.ZipFile(args.archive) as archive:
        members = archive.namelist()
        images = {Path(p).stem:p for p in members if p.startswith("India/train/images/") and p.endswith(".jpg")}
        labels = {Path(p).stem:p for p in members if p.startswith("India/train/annotations/xmls/") and p.endswith(".xml")}
        splits = model_split(images.keys() & labels.keys())
        rows, counts = [], {}
        for split, stems in splits.items():
            count, extras, positives = Counter(), Counter(), 0
            for stem in stems:
                width, height, boxes, other = annotations(archive.read(labels[stem]))
                count.update(box["label"] for box in boxes)
                extras.update(other)
                positives += bool(boxes)
                if split == "test":
                    rows.append(dict(id=stem, src="images/"+stem+".jpg", width=width, height=height,
                                     country="India", split=SPLIT, boxes=boxes, otherCodes=other))
            counts[split] = dict(images=len(stems), positiveImages=positives, negativeImages=len(stems)-positives,
                                 boxes=dict(sorted(count.items())), excludedSourceObjects=dict(sorted(extras.items())))
        indices = {row["id"]:row for row in rows}
        selected = [indices[stem].copy() for stem in gallery_ids(rows)]
        write_corpus(archive, images, selected, args.gallery)
        for row in selected:
            row["src"] = "data/" + row["src"]
        info = dict(dataset="RDD2022", country="India", license="CC BY 4.0", licenseUrl=LICENSE,
                    source=SOURCE, attribution=CREDIT, split=SPLIT,
                    selection="Examples selected for visible damage, class coverage and two images with no target annotations.",
                    coordinateSystem="Top-left normalized xywh, computed from the original XML image dimensions.")
        (args.gallery/"manifest.json").write_text(json.dumps(dict(**info, images=selected), indent=2)+"\n")
        (args.gallery/"split-audit.json").write_text(json.dumps(counts, indent=2)+"\n")
        if args.evaluation:
            write_corpus(archive, images, rows, args.evaluation)
            (args.evaluation/"manifest.json").write_text(json.dumps(dict(**info, images=rows), indent=2)+"\n")
        print(json.dumps(counts, indent=2))
        print(f"Gallery: {len(selected)} images")

if __name__ == "__main__":
    main()
