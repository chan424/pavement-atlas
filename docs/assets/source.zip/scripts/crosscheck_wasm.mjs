// Called by crosscheck_wasm.py with identical float32 fixture tensors.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import * as ort from '../docs/model/vendor/ort.wasm.min.mjs';
import {decode} from '../docs/model/decode.mjs';

const dir = new URL('../docs/model/', import.meta.url);
const [config, cases] = await Promise.all([
  readFile(new URL('config.json', dir), 'utf8').then(JSON.parse),
  readFile(join(process.argv[2], 'cases.json'), 'utf8').then(JSON.parse)
]);
ort.env.wasm.numThreads = 1;
ort.env.wasm.wasmPaths = new URL('vendor/', dir).href;
const checkpoint = await readFile(new URL(config.weights, dir));
assert.equal(createHash('sha256').update(checkpoint).digest('hex'), config.sha256);
const session = await ort.InferenceSession.create(checkpoint, {executionProviders: ['wasm']});
let count = 0, scoreError = 0, coordinateError = 0;
for (const item of cases) {
  const bytes = await readFile(join(process.argv[2], item.file));
  const data = new Float32Array(bytes.buffer, bytes.byteOffset, bytes.byteLength / 4);
  const input = new ort.Tensor('float32', data, [1, 3, config.size, config.size]);
  const outputs = await session.run({[session.inputNames[0]]: input});
  const detections = decode(outputs[session.outputNames[0]], item.geometry, config.classes, .25, config.nmsIou);
  assert.equal(detections.length, item.expected.length, item.id + ': count differs');
  for (const [i, d] of detections.entries()) {
    const [code, score, box] = item.expected[i];
    assert.equal(d.code, code, item.id + ': class differs');
    scoreError = Math.max(scoreError, Math.abs(score - d.score));
    coordinateError = Math.max(coordinateError, ...box.map((x, k) => Math.abs(x - d.box[k])));
    count++;
  }
  input.dispose();
  Object.values(outputs).forEach(t => t.dispose());
}
assert.ok(scoreError <= .001 && coordinateError <= .001, 'backend tolerance exceeded');
await session.release();
console.log(JSON.stringify({images: cases.length, matchedDetections: count, maxScoreDifference: scoreError,
  maxNormalizedCoordinateDifference: coordinateError, nativeVsWasmTolerance: .001}, null, 2));
