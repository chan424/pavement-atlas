"""Re-score the public detector's frozen predictions without downloading any images."""
import gzip
import hashlib
import json
from pathlib import Path
from evaluate import metrics

ROOT = Path(__file__).resolve().parents[1]
research = ROOT / "research"
with gzip.open(research / "public-test-reference.json.gz", "rb") as handle:
    manifest = handle.read()
with gzip.open(research / "public-test-predictions.jsonl.gz", "rt") as handle:
    predictions = [json.loads(line) for line in handle]
reference = json.loads(manifest)["images"]
if [row["id"] for row in predictions] != [row["id"] for row in reference]:
    raise ValueError("Reference and prediction image IDs must match in order")
report = json.loads((research / "india-public-checkpoint-evaluation.json").read_text())
if hashlib.sha256(manifest).hexdigest() != report["manifest_sha256"]:
    raise ValueError("Reference manifest digest changed")
computed, _ = metrics(reference, [row["detections"] for row in predictions],
                      list(report["per_class"]), report["operating_cutoff"])
for name, value in computed.items():
    if value != report[name]:
        raise ValueError(f"Mismatch in {name}")
print(f"Verified {len(reference)} frames, mAP50 {computed['mAP50_101']:.6f}, "
      f"TP/FP/FN {computed['tp']}/{computed['fp']}/{computed['fn']}.")
