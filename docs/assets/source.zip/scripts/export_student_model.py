"""Export a trusted student .pt without changing the site until validation passes.

Install ultralytics, onnx, onnxruntime, and numpy, then run --help.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tempfile

import numpy as np
import onnxruntime as ort
from ultralytics import YOLO


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("weights", type=Path, help="Trusted Ultralytics YOLOv8 or YOLO11 Detect .pt")
    parser.add_argument("--name", required=True, help="Display name uniquely identifying this checkpoint")
    parser.add_argument("--class-map", type=Path, required=True,
                        help='JSON object mapping *checkpoint class names* to D00/D10/D20/D40/OTHER')
    parser.add_argument("--output", type=Path, required=True, help="New empty staging directory")
    args = parser.parse_args()
    mapping = json.loads(args.class_map.read_text())
    model = YOLO(str(args.weights.resolve()))
    if model.task != "detect":
        parser.error("This app requires a bounding-box Detect model.")
    ordered_names = [model.names[i] for i in range(len(model.names))]
    if set(mapping) != set(ordered_names):
        parser.error(f"Mapping keys must exactly match names in the checkpoint: {ordered_names!r}")
    classes = [mapping[name] for name in ordered_names]
    if len(set(classes)) != len(classes) or any(c not in {"D00","D10","D20","D40","OTHER"} for c in classes):
        parser.error("Mapped class codes must be unique and supported by the survey UI.")
    if args.output.exists():
        parser.error("Choose a new output directory.")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=args.output.parent) as temp:
        tempdir = Path(temp)
        shutil.copyfile(args.weights, tempdir / "student.pt")
        copied = YOLO(str(tempdir / "student.pt"))
        export = Path(copied.export(format="onnx", imgsz=640, opset=17, dynamic=False,
                                    simplify=False, nms=False, half=False, batch=1, device="cpu"))
        runtime = ort.InferenceSession(str(export), providers=["CPUExecutionProvider"])
        tensor = np.zeros((1, 3, 640, 640), dtype=np.float32)
        out = runtime.run(None, {runtime.get_inputs()[0].name: tensor})[0]
        if out.ndim != 3 or out.shape[:2] != (1, 4 + len(classes)) or not np.isfinite(out).all():
            parser.error(f"Unexpected output shape or non-finite tensor: {out.shape}")
        stage = tempdir / "validated"
        stage.mkdir()
        sha = hashlib.sha256(export.read_bytes()).hexdigest()
        filename = f"student-{sha[:12]}.onnx"
        shutil.copyfile(export, stage / filename)
        config = {"title": args.name, "weights": "./" + filename, "sha256": sha, "classes": classes,
                  "size": 640, "nmsIou": 0.45}
        (stage / "config.json").write_text(json.dumps(config, indent=2) + "\n")
        stage.rename(args.output)
    print(f"Validated {ordered_names} -> {classes}. Copy the generated files into docs/model/ together.")


if __name__ == "__main__":
    main()
