"""Check the shipped WASM and native CPU backends on identical gallery tensors.

Run with Python + Pillow + numpy + onnxruntime and Node 20+ on PATH.
"""
from pathlib import Path
import json
import subprocess
import tempfile

from PIL import Image
import onnxruntime as ort
from evaluate import ROOT, preprocess, decode


def main():
    docs = ROOT / "docs"
    config = json.loads((docs / "model/config.json").read_text())
    gallery = json.loads((docs / "data/manifest.json").read_text())["images"]
    options = ort.SessionOptions()
    options.intra_op_num_threads = 1
    engine = ort.InferenceSession(str(docs / "model" / config["weights"]), options,
                                  providers=["CPUExecutionProvider"])
    with tempfile.TemporaryDirectory() as dirname:
        folder = Path(dirname)
        rows = []
        for i, entry in enumerate(gallery):
            with Image.open(docs / entry["src"]) as image:
                data, (left, top, sw, sh) = preprocess(image, config["size"])
            output = engine.run(None, {engine.get_inputs()[0].name: data})[0]
            expected = decode(output, (left, top, sw, sh), config, 0.25)
            name = f"{i}.f32"
            data.astype("<f4").tofile(folder / name)
            rows.append({"id": entry["id"], "file": name, "expected": expected,
                         "geometry": {"left": left, "top": top, "scaledWidth": sw, "scaledHeight": sh}})
        (folder / "cases.json").write_text(json.dumps(rows))
        subprocess.run(["node", str(ROOT / "scripts/crosscheck_wasm.mjs"), str(folder)], check=True)


if __name__ == "__main__":
    main()
