#!/usr/bin/env python3
"""Fetch India.zip (about 502 MiB) from the pinned official Figshare v1 archive.

Requires Python 3.10+. Downloads resume in an adjacent hidden temporary folder.
Byte offsets are for immutable Figshare file 38030910 and verified at runtime
against range headers, the ZIP member length and its recorded CRC32.
"""
import argparse
import concurrent.futures
import os
from pathlib import Path
import time
import urllib.request
import zipfile
import zlib

URL = "https://ndownloader.figshare.com/files/38030910"
OFFSET = 609_341_079
LENGTH = 526_709_145
TOTAL = 13_264_172_619
CRC32 = 4_052_154_104
CHUNK = 8 * 1024 * 1024


def valid(path):
    if not path.exists() or path.stat().st_size != LENGTH:
        return False
    crc = 0
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(CHUNK), b""):
            crc = zlib.crc32(chunk, crc)
    return crc == CRC32


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, nargs="?", default=Path("India.zip"))
    args = parser.parse_args()
    output = args.output.resolve()
    if valid(output):
        print(f"Verified {output}")
        return
    output.parent.mkdir(exist_ok=True, parents=True)
    parts = output.parent / ("." + output.name + ".parts")
    parts.mkdir(exist_ok=True)
    starts = range(0, LENGTH, CHUNK)

    def fetch(start):
        size = min(CHUNK, LENGTH - start)
        path = parts / f"{start:012d}.bin"
        if path.exists() and path.stat().st_size == size:
            return path
        first = OFFSET + start
        last = first + size - 1
        request = urllib.request.Request(f"{URL}?rdd2022-range={start}",
                                         headers={"Range":f"bytes={first}-{last}", "Accept-Encoding":"identity"})
        for attempt in range(4):
            try:
                with urllib.request.urlopen(request, timeout=60) as response:
                    if response.status != 206 or response.headers.get("Content-Range") != f"bytes {first}-{last}/{TOTAL}":
                        raise IOError("Source returned an unexpected byte range")
                    data = response.read(size+1)
                    if len(data) != size:
                        raise IOError("Source returned an incomplete chunk")
                tmp = path.with_suffix(".tmp")
                tmp.write_bytes(data)
                os.replace(tmp, path)
                return path
            except OSError:
                if attempt == 3:
                    raise
                time.sleep(2**attempt)

    partial = parts / "assembled.tmp"
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool, partial.open("wb") as target:
        for path in pool.map(fetch, starts):
            target.write(path.read_bytes())
    if not valid(partial) or not zipfile.is_zipfile(partial):
        raise IOError(f"Archive verification failed. Delete {parts} before retrying.")
    os.replace(partial, output)
    for start in starts:
        (parts / f"{start:012d}.bin").unlink()
    parts.rmdir()
    print(f"Verified {output}")

if __name__ == "__main__":
    main()
