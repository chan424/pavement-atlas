"""Check release integrity from the extracted repository. No extra packages required."""
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "docs"
def require(ok, message):
    if not ok:
        raise ValueError(message)
def read(path):
    return json.loads(path.read_text(encoding="utf-8"))
def verify_file(path, sha):
    require(hashlib.sha256(path.read_bytes()).hexdigest() == sha, f"Checksum mismatch: {path}")

class Markup(HTMLParser):
    def handle_starttag(self, name, attrs):
        attrs = dict(attrs)
        for key in ("src", "href"):
            value = attrs.get(key)
            if not value or value.startswith("#") or urlsplit(value).scheme:
                continue
            require((WEB / value).is_file(), f"Missing page asset: {value}")

Markup().feed((WEB / "index.html").read_text())
config = read(WEB / "model/config.json")
verify_file(WEB / "model" / config["weights"], config["sha256"])
manifest = read(WEB / "data/manifest.json")
ids = set()
for photo in manifest["images"]:
    require(photo["id"] not in ids, "Duplicate sample ID")
    ids.add(photo["id"])
    verify_file(WEB / photo["src"], photo["sha256"])
    for box in photo["boxes"]:
        x, y, w, h = [box[k] for k in ("x", "y", "w", "h")]
        require(min(x,y) >= 0 and min(w,h)>0 and x+w<=1.00000001 and y+h<=1.00000001, "Invalid annotation")
a = read(WEB / "data/evaluation.json")
require(a == read(ROOT / "research/india-public-checkpoint-evaluation.json"), "Inconsistent study results")
for key in ("tp","fp","fn"):
    require(sum(v[key] for v in a["per_class"].values()) == a[key], "Operating count mismatch: " + key)
print(f"Verified site entry, relative assets, checkpoint, {len(ids)} reference images and benchmark totals.")
